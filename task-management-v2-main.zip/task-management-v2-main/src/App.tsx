import { ModeToggle } from "./components/mode-toggle";

const App = () => {
  return (
    <div className="flex items-center flex-col gap-6 justify-center h-screen">
      <h1>Hello world</h1>
        <ModeToggle />
    </div>
  );
};

export default App;
